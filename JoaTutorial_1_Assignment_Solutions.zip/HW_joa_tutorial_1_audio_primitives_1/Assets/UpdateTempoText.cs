﻿//
//  Code -> Joe Abbati - January, 2020
//
using UnityEngine;
using UnityEngine.UI;

// joa-> HW1_Tempo - adding function to update BPM Value

public class UpdateTempoText : MonoBehaviour
{
    public Text text;

    public void updateTempoTextValue(float f)
    {
        string bpm = f.ToString("F2");
        text.text = "BPM => " + bpm;
    }
}


