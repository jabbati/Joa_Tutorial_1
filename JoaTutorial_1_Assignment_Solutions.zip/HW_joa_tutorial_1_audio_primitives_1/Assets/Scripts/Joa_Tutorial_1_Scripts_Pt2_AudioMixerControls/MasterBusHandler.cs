﻿//
//  Code -> Joe Abbati - January, 2020
//
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

// joa -> You can force inclusion of Compenents in Code if you'd like - I added them through Editor...
//[RequireComponent(typeof(AudioListener))]
//[RequireComponent(typeof(AudioLowPassFilter))]
// etc

public class MasterBusHandler : MonoBehaviour
{

// joa -> We will need an instance for our MixBusPanelHandler for updates 
// Needed to update/animate the MasterLPFreq UISlider for the LFO and LPFStepper
// * No Test for LFO Active - ASSIGNMENT?
MixBusPanelHandler mixBusPanelHandler;

// Remember to use [Range] to make a Slider in the Objects Inpspector with needed Min/Max values :)
// ONLY FOR STARTUP/INIT VALUES - DOES NOT UPDATE IN RUNTIME - THE UISLIDERS ONLY WHILE RUNNING
[Range(0.001f,1.0f)] [SerializeField] public float theMasterVolume = 0.83f;  
[Range(30F,22000.0f)] [SerializeField] public float theMasterLPFrequency = 400f;  
[Range(1.0f,5.0f)] [SerializeField] public float theMasterLPResonance = 1.2f;  

// joa -> HW1_Tempo
    // joa -> For Tempo/BPM and Subdivision control - hardcoded until controls added...Tutorial_2
    private float BPM = 120.00f;            // default to 120 BPM
    private float stepDivisor = 2.00f;       // default to 1/16 notes
    private float stepValue = 0.250f;       // default stepValue based on subdivision (stepDivisor)

// joa -> HW1_Tempo - just for kicks (lol) - I added a Kick audio source to this to play on start of each
// start of a LPFStepper sequence...
 private AudioSource kickSound;

// Parm's for LPF
[SerializeField] bool lpfActive = false;

// Parms for LFO
// - No BiPolar support yet - need range checking code etc
[SerializeField] bool lfoActive = false;
[SerializeField] bool lfoBiPolar = false;
[SerializeField] bool lpfFreqStepper = false;
    
bool LPFStepperloopBackFlag = false;
bool LPFStepperisPlaying = true;

// Period for Oscillation 0->5 seconds
[Range(0,5)] [SerializeField] float lfo_rate = 2f;    // Init to 2 seconds
// JSA - for Depth- Use [SerializeField] to access via Inspector
[Range(5,500)][SerializeField] float depthFactor = 50f;    // Range 0-1 movement factor

// joa -> Level_1 Concept - WE CAN STEP THROUGH LISTS WITH FOREACH AND INCLUDE YIELD FOR TIMING
[SerializeField] List<float> LPFreqSteps;      // IMPORTANT For EDITOR ONLY - Drag set of blocks into "path"

public AudioMixer masterMixer;

    // joa -> Awake is called BEFORE START!
    private void Awake()
    {
        // joa -> Level_1 Concept Make this a Singleton (w.o Statics)
        // ...if there is more than one of "this"/me, "Destroy" myself
        // ...else Destroy(Object) that is the new instance...
        int numMasterBusHandlers = FindObjectsOfType<MasterBusHandler>().Length; // Remember this method returns an array of existing Objects of this 'Type'

        if (numMasterBusHandlers > 1) 
        {
            Destroy(gameObject);   // gameObject is "This" (Instance)
            print("DENIED REQUEST FOR THE MASTERBUSHANDLER SINGLETON");
        }
        else 
        {
            DontDestroyOnLoad(gameObject); // gameObject is THIS 
            print("MADE THE MASTERBUSHANDLER SINGLETON");
        }
    }

    //Start is called before the first frame update
    void Start()
    {
        // joa -> Get the instance our MixBusPanelHandler for UISlider updates - note the () creating new...
        mixBusPanelHandler = FindObjectOfType<MixBusPanelHandler>();

        // joa -> HW1_Tempo - Get the AudioSource...has AudioClip of Kick sound attached in Editor
        kickSound = GetComponent<AudioSource>();

        // joa -> Set with defaults set from Editor at startup for now
        mixBusPanelHandler.UpdateAllMasterSliders( theMasterVolume, theMasterLPFrequency, theMasterLPResonance );
        SetMasterVolume(theMasterVolume);     
        SetMasterLPFrequency(theMasterLPFrequency);
        SetMasterLPResonance(theMasterLPResonance); 
        if(lpfActive)
            SetMasterLPFWet(0);
        else
            SetMasterLPFWet(-80.0f);

    }

    // joa -> HW1_Tempo - called from OnValueChanged() mapping of TempoSlider...
    public void SetTempo( float f)
    {
       // joa -> Actual step time not same as tempo needs subdivision ...stepDivisor
        BPM = f;
        stepValue = (60.0f/BPM)/stepDivisor;

    }

    // joa -> OUR FIRST COROUTINE/THREAD :D - SIMPLE STEP THROUGH "LIST" 
    // (MADE IN EDITOR FOR NOW...DO DRAGGABLE PREFAB LIST NEXT FOR SEQUENCE OF SOUND "BLOCKS")
    public void StartLPFStepper()
    {
        // DODO NEED BUTTONS AND BUTTON UPDATES - LOCAL TO MIXBUS PANEL OR FROM FUTURE MAIN TRANSPORT - WAIT UNITL TEMPO IS INTEGRATED
        StartCoroutine(LPFFreqStepper(LPFreqSteps));
    }

    public void StopLPFStepper()
    {
        // NEED BUTTONS AND BUTTON UPDATES
        StopCoroutine(LPFFreqStepper(LPFreqSteps));
    }

    public void ToggleLPFStepper()
    {
       if( lpfFreqStepper )
        {
            // JSA - Stop the Frequency sequence - note that it will play through actve List - >
            // Something to address later - when it becomes a call from a TransportHandler, not just a test Toggle...
            StopCoroutine(LPFFreqStepper(LPFreqSteps));
            lpfFreqStepper= !lpfFreqStepper;
            LPFStepperisPlaying = false;
            LPFStepperloopBackFlag = false;
        }
        else
        {
            StartCoroutine(LPFFreqStepper(LPFreqSteps));
            lpfFreqStepper= !lpfFreqStepper;
            LPFStepperisPlaying = true;
        }
    }

    // joa -> Level_1 Concept IEnumerator For a Co-Routine Timer functionality - "yield" with WaitForSeconds(f) 
    // gets List passed in as var - STARTS WITH Toggle in MIX BUS PANEL FOR ToggleLPFStepper()
    // ASSIGNMENT Add a UISlider for Tempo in BPM and a way of selecting subdivision...
    IEnumerator LPFFreqStepper(List<float> LPFreqSteps)    
    {
        //print("Starting Sequence...");
        // joa ->HW1_Tempo - the triggering of the Kick sound I added on strt of LPF Step cylce
        kickSound.Play();
        foreach (float lpf in LPFreqSteps)
        {
            //print("Made a Step");
            SetMasterLPFrequency(lpf);
            mixBusPanelHandler.UpdateMasterLPFrequencySlider(lpf);   // update UISlider

            // joa -> HW1_Tempo - change the yield time to be the BPM/stepDivisor calc of stepValue
            //yield return new WaitForSeconds(0.5f);
            yield return new WaitForSeconds(stepValue);

        }
        //print("Ended Sequence...");
        LPFStepperloopBackFlag = true;      // Cheap way to control looping

    }

    public void SetMasterVolume(float vol)
    {
        // joa -> send using the "Exposed Nanme" of the Audio Mixer Asset component
        // Unity Mixer Range is -80 to 0 (approximate to .001 thru 1.0 and use Log to compensate for dB  non-linearity)
        masterMixer.SetFloat ("masterVolume", Mathf.Log(vol) *20);
    }

    public void SetMasterLPFrequency(float val)
    {
        // joa -> send using the "Exposed Nanme" of the Audio Mixer Asset component
        // Unity LPF Range is 10 Hz to 22 kHz - use log?
        masterMixer.SetFloat ("masterLPFrequency", val);                // update value
    }

    public void SetMasterLPResonance(float val)
    {
        // joa -> send using the "Exposed Nanme" of the Audio Mixer Asset component
        // Unity LPRes Range is 1 to 10 - use log? 5 is a decent max to set in editor of slider range
        masterMixer.SetFloat ("masterLPResonance", val);
    }

    public void SetMasterLPFWet(float val)
    {
        // joa -> send using the "Exposed Nanme" of the Audio Mixer Asset component
        masterMixer.SetFloat ("masterLPFWet", val);
    }

  // joa -> Use of "Expression Body" format
    public void ToggleLFO() => lfoActive = !lfoActive;

// ToggleLPF..
    public void ToggleLPF()
    {
        lpfActive =!lpfActive;
        if(lpfActive)
            SetMasterLPFWet(0);
        else
            SetMasterLPFWet(-80.0f);
    }

    // Update is called once per frame
    void Update()
    { 
        if( lfoActive)
        {
            if (lfo_rate <= Mathf.Epsilon)
            return;
            // joa -> Set osc1_Vect period - Time.time = this frames time in seconds offset
            // from start of Game - grows continually from T=0 of Game
            // Time.time will be FR independant
            // joa -> HW1_Tempo - switch from lfo_rate variable to stepValue calculated in SetTempo()
            //float cycles = Time.time / lfo_rate;
            float cycles = Time.time/stepValue;

            // Get our hook into Radians by using Unity math to get Pi and * 2
            const float tau = Mathf.PI * 2f;
            float rawSine = Mathf.Sin(cycles * tau);   // Goes from -1 to +1
            // joa -> Only UniPolar mode for now
            float  shiftedSine  = ( rawSine / 2f) + 0.5f;    // Scale for 0 to 1
            // joa -> todo... Just a static test value for now...add slider to UI for Assignment?
            float newCutFreq = 400f + (shiftedSine*depthFactor);
            // joa -> Set the filter freq and update the UISlider pos/value - text updates by inheritance
            SetMasterLPFrequency(newCutFreq);
            mixBusPanelHandler.UpdateMasterLPFrequencySlider(newCutFreq);
        }
        // joa -> This will stop the LPFStepper at end of a foreach sequence 
        // Better code for start/stop to follow based on integrating a Master Transport
        if( LPFStepperisPlaying )
        {
            if (LPFStepperloopBackFlag )
            {
                LPFStepperloopBackFlag  = false;
                StartLPFStepper();
            }
        }
    }

} 
