﻿//
//  Code -> Joe Abbati - January, 2020
//
using UnityEngine;

public class MultiSndBlockV1 : MonoBehaviour
{
    // joa -> Add AudioSource to pipeline sound for this block - THIS IS WHAT IS PLAYED/STOPPED
    // - This is the "OUTPUT" for this Objects Sound to the AudioMixer Asset "Group" which it is assigned
    // - In this version there is only the "Master" Active - creating Group (Busses) will be addressed next
    private AudioSource multiSndBlockV1Audio;

    // Vars for BlockState - Adding to Editor for ease of creating patterns...will need to be Prefabs for overides
    [Header("Block State Variables")] 
    [Tooltip("Playing??")][SerializeField] public bool isActive = false;
    [Tooltip("Pitch Scale")] [SerializeField] public float myPitchScale = 1.0f;
    [Tooltip("Color for Active")] [SerializeField] public Color onColor;
    [Tooltip("Color for NOT Active")] [SerializeField] public Color offColor;


    // joa -> We set this range in the UISlider that calls PitchScaleBlockSound(float)...removed from Object/Editor
    //[Range(-.5,1.5)] [SerializeField] public float pitchScale;

     // joa -> Make Editor Fields for selecting possible "AudioClips" for the SndBlock
     [Header("Attach AudioClips to Block")] 
    [SerializeField] AudioClip blockSound_0;
    [SerializeField] AudioClip blockSound_1;
    [SerializeField] AudioClip blockSound_2;
    [SerializeField] AudioClip blockSound_3;



    // Start is called before the first frame update
    void Start()
    {      
        // joa -> Get the AudioSource to 'this' Block instance - 
        multiSndBlockV1Audio = GetComponent<AudioSource>();

        multiSndBlockV1Audio.clip = blockSound_0;
        multiSndBlockV1Audio.pitch = 1.0f;      // set to default pitch
        ChangeBlockColor( offColor );           // "isActive" default to off...
        //multiSndBlockV1Audio.Play();          // use right mouse button to play/stop toggle
       
    }

    public void PlayBlockSound()
    {
        multiSndBlockV1Audio.Play();
        isActive = true;
        //ColorBlockGreen();                    // Demo of direct color assignment for Component
        ChangeBlockColor( onColor );            // Version using Parm setup for Editor Field 'Color'
    }

    public void StopBlockSound() 
    {
        multiSndBlockV1Audio.Stop();
        isActive = false;
        //ColorBlockBlue();
        ChangeBlockColor( offColor );
    }

    // joa -> Execute the .pitch change to the AudioSource of "Prefab"
    public void PitchScaleBlockSound( float scale)
    {
        multiSndBlockV1Audio.pitch = scale;
        myPitchScale = scale;
    }

    public void ColorBlockGreen()
    {
       GetComponent<Renderer>().material.color = Color.green;
    }

    public void ColorBlockBlue()
    {
       GetComponent<Renderer>().material.color = Color.blue;
    }

    public void ColorBlockRed()
    {
      GetComponent<Renderer>().material.color = Color.red;
    }

    public void ChangeBlockColor( Color c)
    {
        GetComponent<Renderer>().material.color = c;
    }


    public void SetActiveSoundNum( int sNum )
    {
        // joa -> Stop and Swap if Playing, otherwise, just swap snd
        if( isActive )
            multiSndBlockV1Audio.Stop();
        switch( sNum )
        {
            case 0:
                multiSndBlockV1Audio.clip = blockSound_0;
            break;
            case 1:
                multiSndBlockV1Audio.clip = blockSound_1;
            break;
            case 2:
                multiSndBlockV1Audio.clip = blockSound_2;
            break; 
            case 3:
                multiSndBlockV1Audio.clip = blockSound_3;
            break;
        }
        if( isActive )
            multiSndBlockV1Audio.Play();
    }


}
