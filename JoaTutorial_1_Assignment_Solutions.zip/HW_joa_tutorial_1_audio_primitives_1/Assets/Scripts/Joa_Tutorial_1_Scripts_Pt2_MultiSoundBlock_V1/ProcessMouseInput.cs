﻿//
//  Code -> Joe Abbati - January, 2020
//
using UnityEngine;

// joa -> Note that this is pretty much a sloppy hack for quick input until we get to a unified transport
// INPUT SYSTEM WILL BE COMPLETELY REWRITTEN GIVEN THINGS WE WILL LEARN AS WE WORK TO MAKE A VERSATILE ENOUGH PREFAB
// FOR NOW, WE WILL BE FOCUSING MORE ON THE AUDIO MIXER ASSET AND ITS REALTIME CONTROL...

public class ProcessMouseInput : MonoBehaviour
{
    private bool playToggle;

    private bool blockIsLeftClicked = false;
    private bool blockIsRightClicked = false;

    // joa -> just hardcoded for now 
    const  int numSnds = 3;
    [SerializeField] [Range(0, numSnds)]  private int sndNum;

    // joa -> We need to get instances of these Object "Types" to access their methods, vars for them...see Start()
    // HW1_FixPrefab -> Access "this" Prefab's TextMesh Directly
    //UpdateTextMesh updateTextMesh;
    TextMesh myTextMesh;
    // HW1_FixPrefab -> Access "this" Prefab's AudioSource Direclty
    MultiSndBlockV1 multiSndBlockV1;

    // Start is called before the first frame update
    void Start()
    {
        // joa -> Level_1 concept FindObjectOfType<>() & GetComponentInChildren<>()
        // HW1_FixPrefab -> Switch the retrieval of TextMesh to Child of Prefab - So use GetCompnentInChildren method instead 
        // of FindObjectOfType() which would find the first in the entire Hierarchy, that would only get the "top" MSB_V1 
         //updateTextMesh = FindObjectOfType<UpdateTextMesh>();
        myTextMesh = GetComponentInChildren<TextMesh>();
       
        // HW1_FixPrefab -> Similar to the above let's now get "this" MSB_V1 instance, not just the first found in the Hieracrchy
        // now Play/Stop are talkint to local/"this" Prefab's instance of "MultiSndBlockV1"
        //multiSndBlockV1 = FindObjectOfType<MultiSndBlockV1>();
        multiSndBlockV1 = GetComponent<MultiSndBlockV1>();

        // -> Use the "Found" Object method to access MultiSndBlockV1, its AudioSource and methods...set playToggle based on its isAcive state
        playToggle = multiSndBlockV1.isActive;
    }

    void OnMouseOver()
    {
        // joa -> detect Left-Mouse click here - just cycle through hardcoded number of sounds for now
        if (Input.GetMouseButtonUp(0))
        {
            sndNum++;
            if(sndNum>numSnds)
                sndNum = 0;
            multiSndBlockV1.SetActiveSoundNum(sndNum);
            // HW1_FixPrefab -> Use the local TextMesh for text update of sndNum NOT the UpdateTextMesh.cs (of which there is only one instance)
            //updateTextMesh.UpdateSndNumTextMesh( sndNum );
            myTextMesh.text = string.Format("Snd:{0:D}", sndNum);           
            blockIsLeftClicked = true;
            print(gameObject.name + "  left clicked");
        }
        else if (Input.GetMouseButtonUp(1))
        {
            blockIsRightClicked = true;
            print(gameObject.name + "  right clicked");

            playToggle = !playToggle;
            if( playToggle )
            {      
                multiSndBlockV1.PlayBlockSound();
            }
            else 
            {
                multiSndBlockV1.StopBlockSound();
            }
        }
    }

}
