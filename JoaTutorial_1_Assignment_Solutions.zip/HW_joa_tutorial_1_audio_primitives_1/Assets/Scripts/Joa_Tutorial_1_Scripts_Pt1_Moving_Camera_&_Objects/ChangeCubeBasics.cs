﻿//
//  Code -> Joe Abbati - January, 2020
//
using UnityEngine;

// Joa - note that these tutorial concepts can be put into a more Generic "Transform" functions class AND you may choose to invert values depending on usage

public class ChangeCubeBasics : MonoBehaviour
{

    # region Joa Variables
    Vector3 myScaleTransform;               // vars for Reset...
    Vector3 myPositionTransform;
    Vector3 myRotationTransform;

    // joa ->  Choose between a method with direct "transform.localxxx OR transform.Translate(xxx)...
    // Make an Inspector vars w/Header & "Toolip" on MouseOver  --- "[SerializeField]" is one of your best friends!
    [Header("transform. or transform.Translate() - 2 methods in code -> Z/C Keys=zAxis w/Translate")]    
    [Header("Use Q/E Keys for Scale in both methods")]  
    [Tooltip("Use this flag to choose mode ")] [SerializeField] bool useTranslateMethod = false;
    
    // joa -> using the tranform.Translate() method is preferred for more control over motion speed/velocity factors using frame rate (Time.deltaTime)
    [Header("Translate Parameters")] 
    [Tooltip("For Translate Example")] [SerializeField] public float moveSpeed = 10f;  
    [Header("Rotate Speed")]
    [Tooltip("For Translate Example")] [SerializeField] public float rotateSpeed = 50f;  
    [Header("Enable/Disable Rotation Axis")] 
    [Header("Use R/T Keys for Rotations")] 
    [SerializeField] bool useX = true;  
    [SerializeField] bool useY = false;  
    [SerializeField] bool useZ = false;  

    // joa -> an example of "clamping" a position value using Transform methed
    [Header("Transform Parameters -> mouseScroll=zAxis w/Transform ")] 
    [SerializeField] bool useXClamping = false;
    [Header("Clamp X +/-")] 
    [Tooltip("Set X Range")] [SerializeField] public float xClamp = 5f;  
    #endregion

    // Start is called before the first frame update
    void Start()
    {
        // joa -> Store the GameObject pos/scale from Scene load, but we will not use Reset on Rotation until we address Quaternians...
        myPositionTransform = this.transform.localPosition;
        myScaleTransform = this.transform.localScale;
        

    }

    // Update is called once per frame
    void Update()
    {
        // joa -> Illustration of 2 different techniques to move a GameObject or Prefab
        // -> with use of Translate() with Vector3.properties and framerate compensation/speed facors [Time.deltaTime]
        if( useTranslateMethod)
            ChangeGameObjectWithTranslate();
        // -> generic "transform" with no use of Translate() or compensation/speed factors + Demo of clapming position bounds
        else
            ChangeGameObjectWithTransformOnly();
  
    }

    private void ChangeGameObjectWithTransformOnly()
    {
        // joa -> Version that uses PlayerSettings->Input Mapping for all except separate call to CheckScaleKeys()
        float xAxisValue = Input.GetAxis("Horizontal");         // Left/Right [pos.x]
        float yAxisValue = Input.GetAxis("Vertical");           // Up/Down [pos.y]
        float zAxisValue = Input.GetAxis("Mouse ScrollWheel");  // In/Out [pos.z]

        // Since both transformand translate versions check for Q/E for scaling, make it a separate method
        CheckScaleKeys();            

        if( useXClamping) 
        {

            float rawXPos = transform.localPosition.x + xAxisValue; 
            // joa -> Use the Editor/var of xClamp to set its range from Left<->Right
            float ClampedrawXPos = Mathf.Clamp(rawXPos, -xClamp, xClamp);  

            // Process the transform change(s)
            transform.position = new Vector3(ClampedrawXPos, 
            transform.position.y + yAxisValue, 
            transform.position.z + zAxisValue);    
        }
        else 
        {
            // joa -> Not "clamped", so it will just keep on moving....
            transform.position = new Vector3(transform.position.x + xAxisValue, 
            transform.position.y + yAxisValue, 
            transform.position.z + zAxisValue);    
        }

        // joa -> Again, use Fire1 from PlayerSettings->Input  to reset the Object localScale/localPosition transform.properties - saved in Start() or Awake()
        if( Input.GetButton("Fire1"))
        {
            ResetScalePositionLocalTransforms();
        }
    }

    private void ChangeGameObjectWithTranslate()
    {
        // joa -> See https://learn.unity.com/tutorial/translate-and-rotate & https://docs.unity3d.com/ScriptReference/Vector3.html
        // In this method straight KeyCode.properties are used through Input.GetKey(x)      
        // Use the move/rotateSpeed parms in the Inspector to observe motion response and learn the different rotation Vector3.properties...

        // X pos with same keys as "Horizontal" Player->Input Defitions 
        if(Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A) )
            transform.Translate(Vector3.left * moveSpeed * Time.deltaTime);      
        if(Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D) )
            transform.Translate(Vector3.right * moveSpeed * Time.deltaTime);

        // Y pos with same keys as "Vertical" Player->Input Definition
        if(Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.W) )
            transform.Translate(Vector3.up * moveSpeed * Time.deltaTime);      
        if(Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.S) )
            transform.Translate(Vector3.down * moveSpeed * Time.deltaTime);

        // Z pos (In/Out) with Z/C Keys Vector3.forward/back is  -> .z parm equivalent to Vector3(0, 0, -1) / Vector3(0, 0, -1) respectively 
        if(Input.GetKey(KeyCode.Z) )
            transform.Translate(Vector3.forward * moveSpeed * Time.deltaTime);      
        if(Input.GetKey(KeyCode.C) )
            transform.Translate(-Vector3.forward * moveSpeed * Time.deltaTime);

       // Use R/T keys to explore rotation - Choose Vector from Inspector...
       // left/right = X-Axis   up/down = Y-Axis  forward/back = Z-Axis
        if(Input.GetKey(KeyCode.R))
        {   
            if(useX)
                transform.Rotate(Vector3.left * rotateSpeed * Time.deltaTime);
            if(useY)
                transform.Rotate(Vector3.up, rotateSpeed * Time.deltaTime);
            if(useZ)
                transform.Rotate(Vector3.forward, rotateSpeed * Time.deltaTime);
        }
        if(Input.GetKey(KeyCode.T))
        {
            if(useX)
                transform.Rotate(Vector3.right * rotateSpeed * Time.deltaTime);
            if(useY)
                transform.Rotate(Vector3.down, rotateSpeed * Time.deltaTime);
            if(useZ)
            transform.Rotate(-Vector3.forward, rotateSpeed * Time.deltaTime);   
        }

        // Since both transformand translate versions check for Q/E for scaling, make it a separate method
        CheckScaleKeys();                   

        if( Input.GetButton("Fire1"))       // Use Fire1 from PlayerSettings->Input  to reset the Object (left mouse click is also = Fire1)
        {
            // joa -> hard set a Quaternion for "reset" of cube transform.rotation 
            transform.rotation = Quaternion.Euler(0.0f, 0.0f, 0.0f); 
            ResetScalePositionLocalTransforms();
        }

    }

    private void CheckScaleKeys()
    {
        // Scale the Cube
        if ( Input.GetKey(KeyCode.Q) )  
        {
            transform.localScale *= 1.1f;    
            
        }    
        if( Input.GetKey(KeyCode.E) )
        {
            transform.localScale *= 0.9f;    
        }  
    }

    private void  ResetScalePositionLocalTransforms()
    {
        // reset to default saved on Start()
        transform.localPosition = myPositionTransform;
        transform.localScale = myScaleTransform;
    }
}
