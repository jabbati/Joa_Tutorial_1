﻿//
//  Code -> Joe Abbati - January, 2020
//
using UnityEngine;

// joa -> Note that this is pretty much a sloppy hack for quick input until we get to a unified transport
// INPUT SYSTEM WILL BE COMPLETELY REWRITTEN GIVEN THINGS WE WILL LEARN AS WE WORK TO MAKE A VERSATILE ENOUGH PREFAB
// FOR NOW, WE WILL BE FOCUSING MORE ON THE AUDIO MIXER ASSET AND ITS REALTIME CONTROL...

public class ProcessMouseInput : MonoBehaviour
{
    private bool playToggle;

    private bool blockIsLeftClicked = false;
    private bool blockIsRightClicked = false;

    // joa -> just hardcoded for now 
    const  int numSnds = 3;
    [SerializeField] [Range(0, numSnds)]  private int sndNum;

    // joa -> We need to get instances of these Object "Types" to access their methods, vars for them...see Start()
    UpdateTextMesh updateTextMesh;
    MultiSndBlockV1 multiSndBlockV1;

    // Start is called before the first frame update
    void Start()
    {
        // joa -> Level_1 concept FindObjectOfType() - now ProcessMouseInput methods can call the other Objects methods...
        updateTextMesh = FindObjectOfType<UpdateTextMesh>();
        multiSndBlockV1 = FindObjectOfType<MultiSndBlockV1>();

        // -> Use the "Found" Object method to access MultiSndBlockV1, its AudioSource and methods...set playToggle based on its isAcive state
        playToggle = multiSndBlockV1.isActive;
    }

    void OnMouseOver()
    {
        // joa -> detect Left-Mouse click here - just cycle through hardcoded number of sounds for now
        if (Input.GetMouseButtonUp(0))
        {
            sndNum++;
            if(sndNum>numSnds)
                sndNum = 0;
            multiSndBlockV1.SetActiveSoundNum(sndNum);

            updateTextMesh.UpdateSndNumTextMesh( sndNum );
            blockIsLeftClicked = true;
            print(gameObject.name + "  left clicked");
        }
        else if (Input.GetMouseButtonUp(1))
        {
            blockIsRightClicked = true;
            print(gameObject.name + "  right clicked");

            playToggle = !playToggle;
            if( playToggle )
            {      
                multiSndBlockV1.PlayBlockSound();
            }
            else 
            {
                multiSndBlockV1.StopBlockSound();
            }
        }
    }

}
