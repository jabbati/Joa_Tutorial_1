﻿//
//  Code -> Joe Abbati - January, 2020
//
using UnityEngine;                                          // THE primary Unity Namespace

public class DriveCameraBasics : MonoBehaviour
{
    // joa -> Store the Camera Object transform(s) : You can use these to revert to settings from initial Scene load
    Vector3 myScaleTransform;           
    Vector3 myPositionTransform;

    // default z-Axis change var on KeyCode(Z/C) - header?
    // joa -> level_1 concept 
    // By using "[SerializeField]" the var can be changed in the Component/Script Inspector
    // By using [Range(0, 3)] the var range in Editor is "clamped' AND it makes a slider in the Objects Inpspector For you :)
    [SerializeField] [Range(0, 3)] float zChangeFactor = 0.5f;    

    // Compare to mouse scroll up/down that just uses raw Input.GetAxis("Mouse ScrollWheel") 
    float zChange = 0.5f;                          

    // Start is called before the first frame update
    void Start()
    {
        // joa -> store the settings from initial Scene load for use as "CAMERA RESET" - See Input.GetButton("Fire1") in Update()
        myPositionTransform = this.transform.localPosition;
        myScaleTransform = this.transform.localScale;
    }

    // Update is called once per frame
    void Update()
    {
        // joa -> see CrossPlatformInput_Settings.png for config of "Input" definitions...
        float xAxisValue = Input.GetAxis("Horizontal");         // NO * scalar used here...addressed later for motion response tuming
        float yAxisValue = Input.GetAxis("Vertical");
        float zAxisValue = Input.GetAxis("Mouse ScrollWheel");  // See "Sensitivity" in the PlayerSettings->Input panel for this "speed"

        // joa ->  To compare z speed vs "Mouse Scroll Wheel", use Z/C for z-Axis delta via zChangFactor var we put in the Inspector...
        // 
        zChange = zChangeFactor;
        if( Input.GetKey(KeyCode.Z) )
            zAxisValue += zChangeFactor;
        if( Input.GetKey(KeyCode.C) )
           zAxisValue -= zChangeFactor;

        // joa -> In Play mode view the Console with "Collapse" enabled and notice that this will be Reset on every Update() 
        // This is why we use other methods later: On Button Up, Timers, Flags etc 
        if( Input.GetButton("Fire1"))                          
        {                                                       // * Mouse Left-Click or Left-Ctrl Key = the default mapping of "Fire1"             
            transform.localPosition = myPositionTransform;      // Reset Cam Position using Vector3 values stored on Start()
            print("CAMERA RESET");                              // print to console...
        }
    
        // joa -> Here the _AxisValues returned from Input method are used to alter this GameObject "transform'
        // SELECT THE CAMERA IN THE HIERARCHY AND VIEW THE CAMERA TRANSFORM VALUES CHANGING IN THE INSPECTOR TAB
        // The GameObject transform/methods are a Level_1 Concept (note, you may want to invert where appropriate...)
        transform.position = new Vector3(transform.position.x + xAxisValue, 
        transform.position.y + yAxisValue, 
        transform.position.z + zAxisValue);

        
    }
}
